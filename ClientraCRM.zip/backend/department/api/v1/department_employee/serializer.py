from rest_framework import serializers

from department.models import DepartmentEmployee


class DepartmentEmployeeListSerializer(serializers.ModelSerializer):

    employee_name = serializers.CharField(
        source="employee.full_name",
        read_only=True,
    )

    department_name = serializers.CharField(
        source="department.name",
        read_only=True,
    )

    class Meta:
        model = DepartmentEmployee

        fields = (
            "id",
            "employee",
            "employee_name",
            "department",
            "department_name",
            "created_at",
            "updated_at",
        )


class DepartmentEmployeeCreateSerializer(serializers.ModelSerializer):

    class Meta:
        model = DepartmentEmployee

        fields = (
            "employee",
            "department",
        )


class DepartmentEmployeeUpdateSerializer(serializers.ModelSerializer):

    class Meta:
        model = DepartmentEmployee

        fields = (
            "department",
        )